/**
 * Copyright (c) 2007-2013 Alysson Bessani, Eduardo Alchieri, Paulo Sousa, and
 * the authors indicated in the @author tags
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package bftsmart.tom;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import bftsmart.communication.ServerCommunicationSystem;
import bftsmart.tom.core.ExecutionManager;
import bftsmart.consensus.messages.MessageFactory;
import bftsmart.consensus.roles.Acceptor;
import bftsmart.consensus.roles.Proposer;
import bftsmart.reconfiguration.ReconfigureReply;
import bftsmart.reconfiguration.ServerViewController;
import bftsmart.reconfiguration.VMMessage;
import bftsmart.tom.core.ReplyManager;
import bftsmart.tom.core.TOMLayer;
import bftsmart.tom.core.messages.TOMMessage;
import bftsmart.tom.core.messages.TOMMessageType;
import bftsmart.tom.core.messages.XACMLType;
import bftsmart.tom.leaderchange.CertifiedDecision;
import bftsmart.tom.server.BatchExecutable;
import bftsmart.tom.server.Executable;
import bftsmart.tom.server.PDPB.EchoMessage;
import bftsmart.tom.server.PDPB.POrder;
import bftsmart.tom.server.Recoverable;
import bftsmart.tom.server.Replier;
import bftsmart.tom.server.RequestVerifier;
import bftsmart.tom.server.SingleExecutable;

import bftsmart.tom.server.defaultservices.DefaultReplier;
import bftsmart.tom.util.KeyLoader;
import bftsmart.tom.util.ShutdownHookThread;
import bftsmart.tom.util.TOMUtil;
import java.security.Provider;

import bftsmart.tom.util.IdPair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class receives messages from DeliveryThread and manages the execution
 * from the application and reply to the clients. For applications where the
 * ordered messages are executed one by one, ServiceReplica receives the batch
 * decided in a consensus, deliver one by one and reply with the batch of
 * replies. In cases where the application executes the messages in batches, the
 * batch of messages is delivered to the application and ServiceReplica doesn't
 * need to organize the replies in batches.
 */
public class ServiceReplica {

    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private int dobadthinglasttime;

    // replica ID
    private int id;
    // Server side comunication system
    private ServerCommunicationSystem cs = null;
    private ReplyManager repMan = null;
    private ServerViewController SVController;
    private ReentrantLock waitTTPJoinMsgLock = new ReentrantLock();
    private Condition canProceed = waitTTPJoinMsgLock.newCondition();
    private Executable executor = null;
    private Recoverable recoverer = null;
    private TOMLayer tomLayer = null;
    private boolean tomStackCreated = false;
    private ReplicaContext replicaCtx = null;
    private Replier replier = null;
    private RequestVerifier verifier = null;

    /**
     * Constructor
     *
     * @param id Replica ID
     * @param executor Executor
     * @param recoverer Recoverer
     */
    public ServiceReplica(int id, Executable executor, Recoverable recoverer) {
        this(id, "", executor, recoverer, null, new DefaultReplier(), null);
    }

    /**
     * Constructor
     *
     * @param id Replica ID
     * @param executor Executor
     * @param recoverer Recoverer
     * @param verifier Requests verifier
     */
    public ServiceReplica(int id, Executable executor, Recoverable recoverer, RequestVerifier verifier) {
        this(id, "", executor, recoverer, verifier, new DefaultReplier(), null);
    }

    /**
     * Constructor
     *
     * @see bellow
     */
    public ServiceReplica(int id, Executable executor, Recoverable recoverer, RequestVerifier verifier, Replier replier) {
        this(id, "", executor, recoverer, verifier, replier, null);
    }

    /**
     * Constructor
     *
     * @see bellow
     */
    public ServiceReplica(int id, Executable executor, Recoverable recoverer, RequestVerifier verifier, Replier replier, KeyLoader loader, Provider provider) {
        this(id, "", executor, recoverer, verifier, replier, loader);
    }
    /**
     * Constructor
     *
     * @param id Replica ID
     * @param configHome Configuration directory for BFT-SMART
     * @param executor The executor implementation
     * @param recoverer The recoverer implementation
     * @param verifier Requests Verifier
     * @param replier Can be used to override the targets of the replies associated to each request.
     * @param loader Used to load signature keys from disk
     */
    public ServiceReplica(int id, String configHome, Executable executor, Recoverable recoverer, RequestVerifier verifier, Replier replier, KeyLoader loader) {
        this.id = id;
        this.SVController = new ServerViewController(id, configHome, loader);
        this.executor = executor;
        this.recoverer = recoverer;
        this.replier = (replier != null ? replier : new DefaultReplier());
        this.verifier = verifier;
        this.init();
        this.recoverer.setReplicaContext(replicaCtx);
        this.replier.setReplicaContext(replicaCtx);

        this.dobadthinglasttime = 0;
    }

    // this method initializes the object
    private void init() {
        try {
            cs = new ServerCommunicationSystem(this.SVController, this);
        } catch (Exception ex) {
            logger.error("Failed to initialize replica-to-replica communication system", ex);
            throw new RuntimeException("Unable to build a communication system.");
        }

        if (this.SVController.isInCurrentView()) {
            logger.info("In current view: " + this.SVController.getCurrentView());
            initTOMLayer(); // initiaze the TOM layer
        } else {
            logger.info("Not in current view: " + this.SVController.getCurrentView());

            //Not in the initial view, just waiting for the view where the join has been executed
            logger.info("Waiting for the TTP: " + this.SVController.getCurrentView());
            waitTTPJoinMsgLock.lock();
            try {
                canProceed.awaitUninterruptibly();
            } finally {
                waitTTPJoinMsgLock.unlock();
            }

        }
        initReplica();
    }

    public void joinMsgReceived(VMMessage msg) {
        ReconfigureReply r = msg.getReply();

        if (r.getView().isMember(id)) {
            this.SVController.processJoinResult(r);

            initTOMLayer(); // initiaze the TOM layer
            cs.updateServersConnections();
            this.cs.joinViewReceived();
            waitTTPJoinMsgLock.lock();
            canProceed.signalAll();
            waitTTPJoinMsgLock.unlock();
        }
    }

    private void initReplica() {
        cs.start();
        repMan = new ReplyManager(SVController.getStaticConf().getNumRepliers(), cs);
    }

    public final void receiveReadonlyMessage(TOMMessage message, MessageContext msgCtx) {
        TOMMessage response;

        // This is used to deliver the requests to the application and obtain a reply to deliver
        //to the clients. The raw decision does not need to be delivered to the recoverable since
        // it is not associated with any consensus instance, and therefore there is no need for
        //applications to log it or keep any proof.
        response = executor.executeUnordered(id, SVController.getCurrentViewId(),
                (message.getReqType() == TOMMessageType.UNORDERED_HASHED_REQUEST &&
                        message.getReplyServer() != this.id),message.getContent(), msgCtx);

        if (response != null) {
            if (SVController.getStaticConf().getNumRepliers() > 0) {
                repMan.send(response);
            } else {
                cs.send(new int[]{response.getSender()}, response.reply);
            }
        }
    }

    /**
     * Stops the service execution at a replica. It will shutdown all threads, stop the requests' timer, and drop all enqueued requests,
     * thus letting the ServiceReplica object be garbage-collected. From the perspective of the rest of the system, this is equivalent
     * to a simple crash fault.
     */
    public void kill() {

        Thread t = new Thread() {

            @Override
            public void run() {
                if (tomLayer != null) {
                    tomLayer.shutdown();
                }
            }
        };
        t.start();
    }

    /**
     * Cleans the object state and reboots execution. From the perspective of the rest of the system,
     * this is equivalent to a rash followed by a recovery.
     */
    public void restart() {
        Thread t = new Thread() {

            @Override
            public void run() {
                if (tomLayer != null && cs != null) {
                    tomLayer.shutdown();

                    try {
                        cs.join();
                        cs.getServersConn().join();
                        tomLayer.join();
                        tomLayer.getDeliveryThread().join();

                    } catch (InterruptedException ex) {
                        logger.error("Interruption while joining threads", ex);
                    }

                    tomStackCreated = false;
                    tomLayer = null;
                    cs = null;

                    init();
                    recoverer.setReplicaContext(replicaCtx);
                    replier.setReplicaContext(replicaCtx);

                }
            }
        };
        t.start();
    }

    public void receiveMessages(int consId[], int regencies[], int leaders[], CertifiedDecision[] cDecs, TOMMessage[][] requests) {
        int numRequests = 0;
        int consensusCount = 0;
        List<TOMMessage> toBatch = new ArrayList<>();
        List<MessageContext> msgCtxts = new ArrayList<>();
        boolean noop = true;
        int[] targets = this.tomLayer.controller.getCurrentViewAcceptors();

        for (TOMMessage[] requestsFromConsensus : requests) {
            long start1 = System.currentTimeMillis();


            TOMMessage firstRequest = requestsFromConsensus[0];
            int requestCount = 0;
            noop = true;
            logger.debug("deliver consensus {}, total number of message is {}", consId[consensusCount], requestsFromConsensus.length);

            List<byte[]> batchedQueryCommands = new ArrayList<byte[]>();
            List<MessageContext> cachedQueryMsgCtx = new ArrayList<MessageContext>();
            List<MessageContext> cachedRexMsgCtx = new ArrayList<MessageContext>();
            List<MessageContext> cachedRespMsgCtx = new ArrayList<MessageContext>();
            ((POrder) executor).updateStartOrderStateLog(consId[consensusCount]);


            for (TOMMessage request : requestsFromConsensus) {

//                logger.debug("Processing TOMMessage decided in consensus " + consId[consensusCount]);

                if (request.getViewID() == SVController.getCurrentViewId()) {

                    if (null == request.getReqType()) {
                        throw new RuntimeException("Should never reach here, request has no xacml type");
                    } else switch (request.getReqType()) {
                        case ORDERED_REQUEST:
                            noop = false;
                            numRequests++;
                            MessageContext msgCtx = new MessageContext(request.getSender(), request.getViewID(),
                                    request.getReqType(), request.getSession(), request.getSequence(), request.getOperationId(),
                                    request.getReplyServer(), request.serializedMessageSignature, firstRequest.timestamp,
                                    request.numOfNonces, request.seed, regencies[consensusCount], leaders[consensusCount],
                                    consId[consensusCount], cDecs[consensusCount].getConsMessages(), firstRequest, false,
                                    request.getXType(), request.getExecutorIds(), requestCount);
                            msgCtx.setReferenceTXId(request.getReferenceTxId());
                            if (request.getXType()==XACMLType.XACML_UPDATE || request.getXType()==XACMLType.XACML_QUERY)
                                logger.debug("the relationship is request {} <-> [{}, {}]", request.toString(),
                                        msgCtx.getConsensusId(), msgCtx.getOrderInBlock());

                            if (requestCount + 1 == requestsFromConsensus.length) {

                                msgCtx.setLastInBatch();
                            }   request.deliveryTime = System.nanoTime();
                            if (executor instanceof BatchExecutable) {

                                logger.debug("Batching request from " + request.getSender());

                                // This is used to deliver the content decided by a consensus instance directly to
                                // a Recoverable object. It is useful to allow the application to create a log and
                                // store the proof associated with decisions (which are needed by replicas
                                // that are asking for a state transfer).
                                if (this.recoverer != null) this.recoverer.Op(msgCtx.getConsensusId(), request.getContent(), msgCtx);

                                // deliver requests and contexts to the executor later
                                msgCtxts.add(msgCtx);
                                toBatch.add(request);
                            } else if (executor instanceof POrder) {
                                if (this.recoverer != null) this.recoverer.Op(msgCtx.getConsensusId(), request.getContent(), msgCtx);

                                switch (msgCtx.getXtype()) {
                                    case XACML_UPDATE: {
                                        ((POrder) executor).appendOrderStateLog("update", request.getContent());
                                        TOMMessage response = ((POrder) executor).executeOrdered(id, SVController.getCurrentViewId(), request.getContent(), msgCtx);

                                        if (response != null) {
                                            response.setToXACMLNop(); // qiwei, add xtype before replying clients
                                            if (response.reply.getContent()==null) {
                                                logger.debug("but the reply is null");
                                            } else {
                                                replier.manageReply(response, msgCtx);
                                            }
                                        } else {
                                            logger.debug("XACML_UPDATE executed returns nothing!");
                                        }
                                        break;
                                    }
                                    case XACML_QUERY: {
                                        ((POrder) executor).appendOrderStateLog("query", request.getContent());
                                        batchedQueryCommands.add(request.getContent());
                                        cachedQueryMsgCtx.add(msgCtx);
                                        break;
                                    }
                                    case XACML_RE_EXECUTED: {
                                        ((POrder) executor).appendOrderStateLog("re_executed", msgCtx.getReferenceTXId().toString().getBytes());
                                        cachedRexMsgCtx.add(msgCtx);
                                        break;
                                    }
                                    case XACML_RESPONDED: {
                                        ((POrder) executor).appendOrderStateLog("re_executed", msgCtx.getReferenceTXId().toString().getBytes());
                                        cachedRespMsgCtx.add(msgCtx);
                                        break;
                                    }
                                }
                            } else if (executor instanceof SingleExecutable) {

                                logger.debug("Delivering request from " + request.getSender() + " via SingleExecutable");

                                // This is used to deliver the content decided by a consensus instance directly to
                                // a Recoverable object. It is useful to allow the application to create a log and
                                // store the proof associated with decisions (which are needed by replicas
                                // that are asking for a state transfer).
                                if (this.recoverer != null) this.recoverer.Op(msgCtx.getConsensusId(), request.getContent(), msgCtx);

                                // This is used to deliver the requests to the application and obtain a reply to deliver
                                //to the clients. The raw decision is passed to the application in the line above.
                                TOMMessage response = ((SingleExecutable) executor).executeOrdered(id, SVController.getCurrentViewId(), request.getContent(), msgCtx);
//                                TOMMessage response = ((POrder) executor).executeOrdered(id, SVController.getCurrentViewId(), request.getContent(), msgCtx);

                                if (response != null) {
                                    response.setToXACMLNop(); // qiwie, add xtype
//                                    logger.info("sending reply to " + response.getSender());
                                    if (response.reply.getContent()==null) {
                                        logger.debug("but the reply is null");
                                    }
                                    replier.manageReply(response, msgCtx);
                                }
                            } else { //this code should never be executed
                                throw new UnsupportedOperationException("Non-existent interface");
                            }   break;
                        case RECONFIG:
                            SVController.enqueueUpdate(request);
                            break;
                        default: //this code should never be executed
                            logger.debug("the type is "+request.getReqType());
                            throw new RuntimeException("Should never reach here!");
                    }
                } else if (request.getViewID() < SVController.getCurrentViewId()) {
                    // message sender had an old view, resend the message to
                    // him (but only if it came from consensus an not state transfer)

                    tomLayer.getCommunication().send(new int[]{request.getSender()}, new TOMMessage(SVController.getStaticConf().getProcessId(),
                            request.getSession(), request.getSequence(), request.getOperationId(), TOMUtil.getBytes(SVController.getCurrentView()), SVController.getCurrentViewId(), request.getReqType()));
                }
                requestCount++;
            }




            byte[][] replies = null;


            // deal with response(rex) first
            if (cachedRexMsgCtx.size()>0) {
                for (int i=0; i<cachedRexMsgCtx.size(); i++) {
                    replies = ((POrder) executor).executeRexInParallel(cachedRexMsgCtx.get(i), consId[consensusCount]);
//                    if (replies==null) logger.info("reply for rex length is null");
                    if (POrder.contains(cachedRexMsgCtx.get(i).getExecutorIds(), id)) {
                        // send reply to clients
                        IdPair batchid = cachedRexMsgCtx.get(i).getReferenceTXId();
                        int vr=0;
//                        logger.debug("reply to client for all queries in re-executed batch {}", batchid.toString());
                        for (IdPair tid: tomLayer.echoManager.mapToTX(batchid)) {

                            MessageContext mctmp = tomLayer.pdpbstate.getTXContext(tid);
                            byte[] commtmp = tomLayer.pdpbstate.getOpContent(tid);
                            TOMMessage response = mctmp.recreateTOMMessage(commtmp);
                            response.reply = new TOMMessage(id, response.getSession(), response.getSequence(), response.getOperationId(),
                                    replies[vr], SVController.getCurrentViewId(), response.getReqType());
                            response.setToXACMLNop();
                            replier.manageReply(response, mctmp);
                            vr++;
                            logger.debug("reply to client for query {} in re-executed batch", tid.toString());
                        }
                    }
                }
            } else {
                logger.debug("there is norex in this block");
            }



            for (MessageContext msgctx: cachedRespMsgCtx) {
                ((POrder) executor).executeOrdered(null, msgctx);
            }


            // then do queries
            boolean destine = false;
            if (id==30) {
                if (consId[consensusCount] - dobadthinglasttime>300) {
                    destine = true;
                }
            } // control sending or not sending reply/echo, for test


            long start2 = 0;
            long duration2 = 0;
            if (cachedQueryMsgCtx.size()>0) {

                // set up echomanger to wait for reply
                for (int i=0; i<cachedQueryMsgCtx.size(); i++) {
                    if ((i+1)%tomLayer.echoManager.getRespCompactSize()==0 || (i+1)==cachedQueryMsgCtx.size()) {
                        MessageContext msgCtx = cachedQueryMsgCtx.get(i);
                        tomLayer.echoManager.setupWait(new IdPair(msgCtx.getConsensusId(), i/tomLayer.echoManager.getRespCompactSize()),
                                msgCtx.getExecutorIds());
                    }
                }

                // now execute the query in parallel
                start2 = System.currentTimeMillis();
                replies = ((POrder) executor).executeQueryInParallel(batchedQueryCommands.toArray(new byte[0][]),
                        cachedQueryMsgCtx.toArray(new MessageContext[0]), consId[consensusCount]);
                duration2 = System.currentTimeMillis()-start2;
                // convert byte[] to TOMMessage then send the reply
                byte[][] replyToCompress = new byte[tomLayer.echoManager.getRespCompactSize()][];


                for (int i=0; i<replies.length; i++) {
                    MessageContext msgCtx = cachedQueryMsgCtx.get(i);
                    int cind = i%tomLayer.echoManager.getRespCompactSize();
                    replyToCompress[cind] = replies[i];


                    if (POrder.contains(msgCtx.getExecutorIds(), id)) {
                        IdPair tid = new IdPair(msgCtx.getConsensusId(), msgCtx.getOrderInBlock());


                        // send response to clients
                        if (destine) {
                            // avoid sending
                            logger.info("avoid sending reply for tx {}", tid.toString());
                            dobadthinglasttime = consId[consensusCount];
                        } else {
                            // send as usual
                            TOMMessage response = cachedQueryMsgCtx.get(i).recreateTOMMessage(batchedQueryCommands.get(i));
                            response.reply = new TOMMessage(this.id, response.getSession(), response.getSequence(), response.getOperationId(),
                                    replies[i], SVController.getCurrentViewId(), response.getReqType());
                            response.setToXACMLNop(); // qiwei, add xtype before replying clients
                            replier.manageReply(response, msgCtx);
//                            logger.debug("executed an XACML_QUERY, sent the reply");
                        }


                        // send echo to other servers
                        if ((i+1)%tomLayer.echoManager.getRespCompactSize()==0 || (i+1)==cachedQueryMsgCtx.size()) {

                            IdPair bid = tomLayer.echoManager.mapToBatch(tid);
//                            logger.info("bid=({}, {}), replyToCompress is:", bid.getX(), bid.getY());
//                            for (int j=0; j<replies.length; j++) {
//                                logger.info("bid=({}, {}), replyToCompress: {}", bid.getX(), bid.getY(), new String(replyToCompress[j]));
//                            }
                            EchoMessage em = new EchoMessage(this.id, bid.getX(), bid.getY(), replyToCompress);
//                            this.tomLayer.getCommunication().send(targets, em);

                            if (destine) {
                                logger.debug("avoid sending echo for batch {}", bid.toString());
                            } else {
                                this.tomLayer.getCommunication().send(targets, em);
                                logger.debug("sent echo for batch ({}, {})", bid.getX(), bid.getY());
                            }
                        }


                    }
                }
            }




            // finally, do checkpoint (if necessary)
            ((POrder) executor).updateBatchSize(cachedQueryMsgCtx.size());
            ((POrder) executor).updateEndOrderStateLog();
            ((POrder) executor).doCheckPoint(consId[consensusCount]);


            // This happens when a consensus finishes but there are no requests to deliver
            // to the application. This can happen if a reconfiguration is issued and is the only
            // operation contained in the batch. The recoverer must be notified about this,
            // hence the invocation of "noop"
            if (noop && this.recoverer != null) {

                logger.debug("Delivering a no-op to the recoverer");

                logger.info("A consensus instance finished, but there were no commands to deliver to the application.");
                logger.info("Notifying recoverable about a blank consensus.");

                byte[][] batch = null;
                MessageContext[] msgCtx = null;
                if (requestsFromConsensus.length > 0) {
                    //Make new batch to deliver
                    batch = new byte[requestsFromConsensus.length][];
                    msgCtx = new MessageContext[requestsFromConsensus.length];

                    //Put messages in the batch
                    int line = 0;
                    for (TOMMessage m : requestsFromConsensus) {
                        batch[line] = m.getContent();

                        msgCtx[line] = new MessageContext(m.getSender(), m.getViewID(),
                            m.getReqType(), m.getSession(), m.getSequence(), m.getOperationId(),
                            m.getReplyServer(), m.serializedMessageSignature, firstRequest.timestamp,
                            m.numOfNonces, m.seed, regencies[consensusCount], leaders[consensusCount],
                            consId[consensusCount], cDecs[consensusCount].getConsMessages(), firstRequest,
                                true, m.getXType(), m.getExecutorIds(), line);
                        msgCtx[line].setLastInBatch();

                        line++;
                    }
                }

                this.recoverer.noOp(consId[consensusCount], batch, msgCtx);

                //MessageContext msgCtx = new MessageContext(-1, -1, null, -1, -1, -1, -1, null, // Since it is a noop, there is no need to pass info about the client...
                //        -1, 0, 0, regencies[consensusCount], leaders[consensusCount], consId[consensusCount], cDecs[consensusCount].getConsMessages(), //... but there is still need to pass info about the consensus
                //        null, true); // there is no command that is the first of the batch, since it is a noop
                //msgCtx.setLastInBatch();

                //this.recoverer.noOp(msgCtx.getConsensusId(), msgCtx);
            }


            long duration1 = System.currentTimeMillis()-start1;
//            logger.info("consensus instance {} delivering time costs: {} ms, processing query costs {} ms, querynum: {}, rexnum: {}",
//                    consId[consensusCount], duration1, duration2, cachedQueryMsgCtx.size(), cachedRexMsgCtx.size());

            consensusCount++;
        }

        if (executor instanceof BatchExecutable && numRequests > 0) {
            //Make new batch to deliver
            byte[][] batch = new byte[numRequests][];

            //Put messages in the batch
            int line = 0;
            for (TOMMessage m : toBatch) {
                batch[line] = m.getContent();
                line++;
            }

            MessageContext[] msgContexts = new MessageContext[msgCtxts.size()];
            msgContexts = msgCtxts.toArray(msgContexts);

            //Deliver the batch and wait for replies
            TOMMessage[] replies = ((BatchExecutable) executor).executeBatch(id, SVController.getCurrentViewId(), batch, msgContexts);

            //Send the replies back to the client
            if (replies != null) {

                for (TOMMessage reply : replies) {

                    if (SVController.getStaticConf().getNumRepliers() > 0) {
                        logger.debug("Sending reply to " + reply.getSender() + " with sequence number " + reply.getSequence() + " and operation ID " + reply.getOperationId() +" via ReplyManager");
                        repMan.send(reply);
                    } else {
                        logger.debug("Sending reply to " + reply.getSender() + " with sequence number " + reply.getSequence() + " and operation ID " + reply.getOperationId());
//                        reply.setToXACMLNop(); // qiwei, add xtype
                        replier.manageReply(reply, null);
                        //cs.send(new int[]{request.getSender()}, request.reply);
                    }
                }
            }
            //DEBUG
            logger.debug("BATCHEXECUTOR END");
        }
    }

    /**
     * This method initializes the object
     *
     * @param cs Server side communication System
     * @param conf Total order messaging configuration
     */
    private void initTOMLayer() {
        if (tomStackCreated) { // if this object was already initialized, don't do it again
            return;
        }

        if (!SVController.isInCurrentView()) {
            throw new RuntimeException("I'm not an acceptor!");
        }

        // Assemble the total order messaging layer
        MessageFactory messageFactory = new MessageFactory(id);

        Acceptor acceptor = new Acceptor(cs, messageFactory, SVController);
        cs.setAcceptor(acceptor);

        Proposer proposer = new Proposer(cs, messageFactory, SVController);

        ExecutionManager executionManager = new ExecutionManager(SVController, acceptor, proposer, id);

        acceptor.setExecutionManager(executionManager);

        tomLayer = new TOMLayer(executionManager, this, recoverer, acceptor, cs, SVController, verifier);

        executionManager.setTOMLayer(tomLayer);

        SVController.setTomLayer(tomLayer);

        cs.setTOMLayer(tomLayer);
        cs.setRequestReceiver(tomLayer);

        acceptor.setTOMLayer(tomLayer);

        if (SVController.getStaticConf().isShutdownHookEnabled()) {
            Runtime.getRuntime().addShutdownHook(new ShutdownHookThread(tomLayer));
        }
        replicaCtx = new ReplicaContext(cs, SVController);

        tomLayer.start(); // start the layer execution
        tomStackCreated = true;

    }

    /**
     * Obtains the current replica context (getting access to several
     * information and capabilities of the replication engine).
     *
     * @return this replica context
     */
    public final ReplicaContext getReplicaContext() {
        return replicaCtx;
    }


    /**
     * Obtains the current replica communication system.
     *
     * @return The replica's communication system
     */
    public ServerCommunicationSystem getServerCommunicationSystem() {

        return cs;
    }

    /**
     * Replica ID
     * @return Replica ID
     */
    public int getId() {
        return id;
    }

    public TOMLayer getTomLayer() {return tomLayer;}


}
